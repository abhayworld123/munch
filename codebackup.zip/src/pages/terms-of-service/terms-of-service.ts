import { Component } from "@angular/core";

@Component({
  templateUrl: "terms-of-service.html",
  selector: 'terms-of-service',
})

export class TermsOfServicePage {
  constructor() {
  }

  ngOnInit() {

  }
}
